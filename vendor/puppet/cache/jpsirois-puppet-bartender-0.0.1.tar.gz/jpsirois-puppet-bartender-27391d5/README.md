# [Bartender.app](http://www.macbartender.com) Puppet Module for Boxen

[![Build Status](https://travis-ci.org/jpsirois/puppet-bartender.png)](https://travis-ci.org/jpsirois/puppet-bartender)

## Usage

```puppet
include bartender
```

## Required Puppet Modules

* boxen

## Developing

Write code.

Run `script/cibuild`.
